Requirement:
1. Authorized to access Internet.
2. Test it with Chrome browser.

Operation:
1. Run "index.html" as the home page.
2. Buttons in the pages have not actual effects 
without the undeveloped backend.

@Hongyong Zhang
